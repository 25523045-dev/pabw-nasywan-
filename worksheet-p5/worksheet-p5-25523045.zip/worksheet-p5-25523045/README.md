# Pertemuan 5 — Layout Modern: Flexbox dan Grid

Berkas: `profil.html`, `tokens.css`, `base.css`, `layout.css`, `komponen.css`, dan `tema.css`.

## Perubahan dari Pertemuan 4

- Kerangka halaman menggunakan CSS Grid dengan tiga baris: `auto 1fr auto`.
- Area isi menggunakan dua kolom dengan `16rem 1fr` dan `gap`.
- Navbar menggunakan Flexbox.
- Isi kartu menggunakan Flexbox.
- Galeri menggunakan `repeat(auto-fit, minmax(16rem, 1fr))` tanpa media query.
- Item flex/grid diberi `min-width: 0` agar isi panjang tidak mendorong kolom keluar.
- Tabel dibungkus dengan `.tabel-wrap` agar tetap aman pada layar sempit.
- Tema gelap dan token dari Pertemuan 4 tetap dipertahankan.

## Pengujian

Halaman perlu diperiksa pada lebar sekitar 360 px dan 1.280 px. Pastikan tidak ada elemen utama yang meluber keluar kotaknya dan galeri dapat menyesuaikan jumlah kolom secara otomatis.

AI digunakan untuk membantu penyusunan dan pemeriksaan kode. Hasil tetap ditinjau dan disesuaikan dengan struktur halaman Pertemuan 4.
